--
-- This plugin add Gotham colorscheme.
--

VERSION = "1.1.0"

AddRuntimeFile("gotham-colors", "colorscheme", "gotham.micro")
