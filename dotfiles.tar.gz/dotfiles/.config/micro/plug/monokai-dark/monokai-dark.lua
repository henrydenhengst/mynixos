VERSION = "0.1.0"

AddRuntimeFile("monokai-dark", "colorscheme", "monokai-dark.micro")
